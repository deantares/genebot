
import java.util.*;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author antares
 */
public class Antabot {

     public static void DoTurn(PlanetWars pw) {
         //Variables
         Random aleatorio = new Random(); //Variable aleatoria
         Planet base = null; //Es la base principal de nuestro ejercito
         double diezmo = 0.10;

         //Localizamos el planeta principal
	double flotabase = Double.MIN_VALUE;
	for (Planet p : pw.MyPlanets()) {
	    double flota = (double)p.NumShips();
	    if (flota > flotabase) {
		flotabase = flota;
		base = p;
	    }
	}

        if(aleatorio.nextDouble() < 0.5){
            //Toca diezmo
             for (Planet colonia : pw.MyPlanets() ){
                if (colonia != base){
                    int numShips = (int) (colonia.NumShips() * diezmo);
                    if(numShips!=0) pw.IssueOrder(colonia, base, numShips);
                    }
                }
         }


        //Pasamos revista para ver a que planetas estamos enviando naves. Mandar dos tripulaciones es un gasto estúpido.

       int [] v = new int [pw.NumPlanets()];

        for(Fleet naves : pw.MyFleets() ){v[naves.DestinationPlanet()] = 1;}
	
	// Localizamos el siguiente planeta que vamos a atacar. Atacamos como mucho un planeta por turno
	Planet objetivo = null;
	double flotasobjetivo = Double.MAX_VALUE;
	for (Planet p : pw.NotMyPlanets()) {
            boolean atacando = false;
            double score = p.NumShips();
                
                if((score < flotasobjetivo) && v[p.PlanetID()]==0) {
                    flotasobjetivo = score;
                    objetivo = p;
                }
	}
	// (4) Mandamos las tropas de la base al objetivo
        if(base != null && objetivo != null ){
        if(objetivo.Owner()== 0){
            //Estamos expandiendo, por tanto no tenemos generación de tropas.
            if (base.NumShips() > objetivo.NumShips()) {
                int armada = (int) (1 + objetivo.NumShips());
                pw.IssueOrder(base, objetivo, armada);
            }
         } else{
            //Estamos conquistando, por tanto tenemos generación de tropas. Lo consideramos
            int a = (pw.Distance(base.PlanetID(), objetivo.PlanetID()) * objetivo.GrowthRate()) + objetivo.NumShips() + 1;

            if (base.NumShips()  > a) {
                int armada = a;
                pw.IssueOrder(base, objetivo, armada);
            }
         }}


    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        String line = "";
	String message = "";
	int c;
	try {
	    while ((c = System.in.read()) >= 0) {
		switch (c) {
		case '\n':
		    if (line.equals("go")) {
			PlanetWars pw = new PlanetWars(message);
			DoTurn(pw);
		        pw.FinishTurn();
			message = "";
		    } else {
			message += line + "\n";
		    }
		    line = "";
		    break;
		default:
		    line += (char)c;
		    break;
		}
	    }
	} catch (Exception e) {
	    // Owned.
	}
    }
    }
