/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package genebot;


import java.util.*;
import java.io.*;

/**
 *
 * @author antares
 */
public class Main {

    public static ArrayList<individuo> load_poblation(String fichero){
        return null;
    }

    public static void fitness(individuo tio){
        boolean gana = true;
        int [] turnos = {0,0,0,0,0};
        //Mapas en los que más planetas hay, menos planetas, pierde inanición, más tarda en ganar, menos tarda.
        int [] mapas = {76,69,7,11,26};

        for(int i = 0; i<mapas.length; i++){

        try {
            ProcessBuilder pb = new ProcessBuilder("./lanzar", Integer.toString(mapas[i]), Double.toString(tio.cromo[0]) ,Double.toString(tio.cromo[1]) , Double.toString(tio.cromo[2]), Double.toString(tio.cromo[3]), Double.toString(tio.cromo[4]), Double.toString(tio.cromo[5]), Double.toString(tio.cromo[6]), Double.toString(tio.cromo[7]));
            pb.redirectErrorStream(true); // Mezclamos todas las salidas

            Process p = pb.start(); //Lanzamos la hebra
            InputStreamReader isr = new  InputStreamReader(p.getInputStream());
            BufferedReader br = new BufferedReader(isr);

            String lineRead;
            while ((lineRead = br.readLine()) != null) {
                   //System.out.println(lineRead);
                }

            int rc = p.waitFor(); //Esperamos que termine la ejecución del juego y sepamos el resultado

            File archivo = new File ("aa.txt");
            FileReader fr = new FileReader (archivo);
            BufferedReader br2 = new BufferedReader(fr);
            String linea, winer="",turn="";

                 // Lectura del fichero
            while((linea=br2.readLine())!=null){
               // System.out.print("-");
                turn=winer;
                if(winer!="Draw!") winer=linea;
                else {
                    br2.readLine();
                    winer = linea;
                }

            }

            //In line 3 we have the numbers of turn and in line2 we have the result
            if(winer.charAt(7)=='2') {gana=false;}
            //System.out.println(Integer.parseInt(turn.substring(5)));
            //tio.turnos=Integer.parseInt(turn.substring(5));
            turnos[i]=Integer.parseInt(turn.substring(5));
            fr.close();
            br2.close();
            p.destroy();


        }
        catch (IOException e) {
            e.printStackTrace(); // or log it, or otherwise handle it
        }
        catch (InterruptedException ie) {
            ie.printStackTrace(); // or log it, or otherwise handle it
        }finally{
            
        }
        }

       tio.turnos = turnos[0]+turnos[1]+turnos[2]+turnos[3]+turnos[4];
       tio.gana = gana;
    }

    public static void fitness(individuo tio, String file){
        boolean gana = true;
        int [] turnos = {0,0,0,0,0};
        //Mapas en los que más planetas hay, menos planetas, pierde inanición, más tarda en ganar, menos tarda.
        int [] mapas = {76,69,7,11,26};

        for(int i = 0; i<mapas.length; i++){

        try {
            ProcessBuilder pb = new ProcessBuilder("./lanzar", Integer.toString(mapas[i]), Double.toString(tio.cromo[0]) ,Double.toString(tio.cromo[1]) , Double.toString(tio.cromo[2]), Double.toString(tio.cromo[3]), Double.toString(tio.cromo[4]), Double.toString(tio.cromo[5]), Double.toString(tio.cromo[6]), Double.toString(tio.cromo[7]));
            pb.redirectErrorStream(true); // Mezclamos todas las salidas

            Process p = pb.start(); //Lanzamos la hebra
            InputStreamReader isr = new  InputStreamReader(p.getInputStream());
            BufferedReader br = new BufferedReader(isr);

            String lineRead;
            while ((lineRead = br.readLine()) != null) {
                   //System.out.println(lineRead);
                }

            int rc = p.waitFor(); //Esperamos que termine la ejecución del juego y sepamos el resultado

            File archivo = new File (file);
            FileReader fr = new FileReader (archivo);
            BufferedReader br2 = new BufferedReader(fr);
            String linea, winer="",turn="";

                 // Lectura del fichero
            while((linea=br2.readLine())!=null){
               // System.out.print("-");
                turn=winer;
                if(winer!="Draw!") winer=linea;
                else {
                    br2.readLine();
                    winer = linea;
                }

            }

            //In line 3 we have the numbers of turn and in line2 we have the result
            if(winer.charAt(7)=='2') {gana=false;}
            //System.out.println(Integer.parseInt(turn.substring(5)));
            //tio.turnos=Integer.parseInt(turn.substring(5));
            turnos[i]=Integer.parseInt(turn.substring(5));
            fr.close();
            br2.close();
            p.destroy();


        }
        catch (IOException e) {
            e.printStackTrace(); // or log it, or otherwise handle it
        }
        catch (InterruptedException ie) {
            ie.printStackTrace(); // or log it, or otherwise handle it
        }finally{

        }
        }

       tio.turnos = turnos[0]+turnos[1]+turnos[2]+turnos[3]+turnos[4];
       tio.gana = gana;
    }


    public static void start_espectro(ArrayList< individuo > poblacion){
        //¿Cómo generamos la población iniciar? Unidistribuimos las variables.
//        individuo a = new individuo();

        double[] i={0,0,0,0,0,0,0,0,0};
        double inicial = 0.3;
        double incr = 0.3;

        for (i[0]=inicial; i[0]<=1;i[0]=i[0]+incr)
            for (i[1]=inicial; i[1]<=1;i[1]=i[1]+incr)
                for (i[2]=inicial; i[2]<=1;i[2]=i[2]+incr)
                    for (i[3]=inicial; i[3]<=1;i[3]=i[3]+incr)
                        for (i[4]=inicial; i[4]<=1;i[4]=i[4]+incr)
                            for (i[5]=inicial; i[5]<=1;i[5]=i[5]+incr)
                                for (i[6]=inicial; i[6]<=1;i[6]=i[6]+incr)
                                    for (i[7]=inicial; i[7]<=1;i[7]=i[7]+incr)
                                            poblacion.add(new individuo(new double []{i[0],i[1],i[2],i[3],i[4],i[5],i[6],i[7]}) );
                    
                
            
                
    }

    public static void start_random(ArrayList< individuo > poblacion, int tama){
        //¿Cómo generamos la población iniciar? Unidistribuimos las variables.
//        individuo a = new individuo();

        Random aleatorio = new Random(System.currentTimeMillis());

        for (int i=0; i<tama;i++){
                 poblacion.add(new individuo(new double []{aleatorio.nextDouble(),aleatorio.nextDouble(),aleatorio.nextDouble(),aleatorio.nextDouble(),aleatorio.nextDouble(),aleatorio.nextDouble(),aleatorio.nextDouble(),aleatorio.nextDouble()}) );
        }
    }

    public static void mutation (double cromo, double factor){
        Random ale = new Random(System.currentTimeMillis());
        if (ale.nextDouble() <= factor){
            //Un gen es mutado
            cromo=ale.nextDouble();
        }

    }

    public static void recombination_part (individuo t1, individuo t2, double [] out){
        Random ale = new Random(System.currentTimeMillis());
        int cut = ale.nextInt(t1.cromo.length);
        for (int i=0; i<t1.cromo.length;i++){
            out[i]= i<cut ? t1.cromo[i] : t2.cromo[i];
        }

    }

    public static void recombination_blx (individuo t1, individuo t2, double [] a1, double [] a2){

        Random ale = new Random(System.currentTimeMillis());
        double alfa = 0.5;
        for (int i=0; i<t1.cromo.length;i++){
            double cmax= t1.cromo[i]>t2.cromo[i] ? t1.cromo[i] : t2.cromo[i];
            double cmin= t1.cromo[i]<t2.cromo[i] ? t1.cromo[i] : t2.cromo[i];
            double I= cmax - cmin;
           // System.err.print(ale.nextDouble() * ((cmin - I *alfa) - (cmax + I *alfa) )+ (cmin - I *alfa));

            double maxRange=1,minRange=0;
            
            double limSup = cmax + (alfa*I);
            double limInf = cmin - (alfa*I);
            
            if(limSup > maxRange) limSup = maxRange;
            if(limInf < minRange) limInf = minRange;

            a1[i]=  ale.nextDouble() * (limSup - limInf ) + (limInf);
            a2[i]=  ale.nextDouble() * (limSup - limInf ) + (limInf);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Variables generales del algoritmo
        int generaciones=0; //Generación actual
        FileWriter salida = null; //Fichero de salida
        PrintWriter pw = null; //Flujo de salida
        int n_genes = 8; //Número de genes
        Random aleatorio = new Random(System.currentTimeMillis()); //Semilla aleatoria

        //Parámetros de salida de pantalla
        int i=0; //Contador por defecto
        int n_sal_pantalla = 5; // Número de individuos procesados para mostrar indicación en pantalla

        //Parámetros de entrada del algoritmo por defecto
        double factor_mutacion = 0.1; //Factor de mutación
        double factor_crossover = 0.8; //Factor de crossover
        int size = 200; //Tamaño de la población
        int total_generaciones = 20; //Número máximo de generaciones
        int nts = 2; //Número de individuos en torneo
        int n_eli = 4; //Cantidad de individuos que pasan por elitismo


        //Miramos los parámetros pasados del genético

        for(int j = 0; j < args.length; j++)
        {
            if(args[j].equals("--fm"))
            {
                if(j+1 >= args.length)
                {
                    System.err.println("Parámetros incorrectos");
                    System.exit(0);
                }

                    factor_mutacion = Double.parseDouble(args[j+1]);

            }else if(args[j].equals("--fc"))
            {
                if(j+1 >= args.length)
                {
                    System.err.println("Parámetros incorrectos");
                    System.exit(0);
                }

                    factor_crossover = Double.parseDouble(args[j+1]);

            }else if(args[j].equals("--s"))
            {
                if(j+1 >= args.length)
                {
                    System.err.println("Parámetros incorrectos");
                    System.exit(0);
                }

                    size = Integer.parseInt(args[j+1]);

            }else if(args[j].equals("--g"))
            {
                if(j+1 >= args.length)
                {
                    System.err.println("Parámetros incorrectos");
                    System.exit(0);
                }
                    total_generaciones= Integer.parseInt(args[j+1]);

            }else if(args[j].equals("--nts"))
            {
                if(j+1 >= args.length)
                {
                    System.err.println("Parámetros incorrectos");
                    System.exit(0);
                }
                    nts= Integer.parseInt(args[j+1]);

            }else if(args[j].equals("--neli"))
            {
                if(j+1 >= args.length)
                {
                    System.err.println("Parámetros incorrectos");
                    System.exit(0);
                }
                    n_eli = Integer.parseInt(args[j+1]);

            }

        }

        System.out.println("Empezando algoritmo genético con los siguientes parámetros");
        System.out.println("==============================================================");
        System.out.println("Factor mutación: " + factor_mutacion);
        System.out.println("Factor crossover: " + factor_crossover);
        System.out.println("Total generaciones: " + total_generaciones);
        System.out.println("Tamaño población: " + size);
        System.out.println("Número individuos torneo: " + nts);
        System.out.println("Cantidad de individuos elitimo: " + n_eli);

        // Mierdaaaaaaaaaaaaaaaaaaaaaaaa

        //System.exit(0);
        
        //Creamos la población
        ArrayList< individuo > poblacion = new ArrayList< individuo >();
        ArrayList< individuo > poblacion_futura = new ArrayList< individuo >();


        //Inicializamos
        System.err.println("Inicializando población");
        //start_espectro(poblacion);
        start_random(poblacion, size);

        //Evaluamos toda la población
        long tiempoInicio = System.currentTimeMillis();
        System.err.println("Evaluando población:"+poblacion.size());
        
        for(individuo a : poblacion){
                System.err.print(".");
            if(i%n_sal_pantalla==0){
                long totalTiempo = System.currentTimeMillis() - tiempoInicio;
                System.err.print(i+"("+(double) totalTiempo/1000/60+" min)");
            }
                fitness(a,"aa.txt");
                
                if(a.turnos<=5) System.err.println("Algo está fallando :( " + a.ToString());
                i++;
        }

        System.err.println("\n Ajustando población");

        //Ordenamos
        Collections.sort(poblacion, new IndividuoComparator());
        
        System.err.println("Almacenando información sobre individuos");
        //Almacenamos
        try{
        salida = new FileWriter("./logs/genera"+Integer.toString(generaciones)+".txt");
        pw = new PrintWriter (salida);

        for(individuo a: poblacion){
          //System.err.println(a.ToString());
            pw.println(a.ToString());

        }
        }catch (Exception e) {
             e.printStackTrace();
        } finally {
           try {
           // Nuevamente aprovechamos el finally para
           // asegurarnos que se cierra el fichero.
           if (null != salida)
              salida.close();
           } catch (Exception e2) {
              e2.printStackTrace();
           }
        }


        //Comienza el algoritmo genético en si

        while(generaciones < total_generaciones){
            generaciones++;

            System.out.println("La población se encuentra en la " + generaciones + " generación");
            System.err.println("Población:"+poblacion.size());
            //Elitimos
            for(int j=0; j<n_eli;j++) poblacion_futura.add(poblacion.get(j));

            //Selecionamos un individuo
            for(individuo t1: poblacion){
                int selecion;
                int sel=poblacion.size();
                //Selecionamos su torneo. Hemos generado n números aleatorios que indican la posición de los indiviuos en el array. Como están ordenados según su fitness, nos quedamos con el menor
                for(int j =0 ; j< nts; j++){
                    selecion=aleatorio.nextInt(poblacion.size());
                    if(selecion<sel && !t1.equals(poblacion.get(selecion))){
                        sel = selecion;
                    }
                }

                //en sel tenemos la posición del individuo que vamos a cruzar.
                double [] h1={0,0,0,0,0,0,0,0},h2={0,0,0,0,0,0,0,0};

                //Hacemos que los padres tengan descendencia
                if(aleatorio.nextDouble()<=factor_crossover){

                recombination_blx(t1, poblacion.get(sel), h1, h2);
                //recombination_part(t1, poblacion.get(sel), h1);

                }else{
                    h1[0]=t1.cromo[0];
                    h1[1]=t1.cromo[1];
                    h1[2]=t1.cromo[2];
                    h1[3]=t1.cromo[3];
                    h1[4]=t1.cromo[4];
                    h1[5]=t1.cromo[5];
                    h1[6]=t1.cromo[6];
                    h1[7]=t1.cromo[7];
                }

                //Mutación
                for(i= 0 ;i<h1.length;i++){
                    mutation(h1[i],factor_mutacion);
                    mutation(h2[i],factor_mutacion);
                }


                //Añadimos uno de los dos individuos a la población.
                poblacion_futura.add(new individuo(h1));
               // poblacion_futura.add(new individuo(h2));
                //poblacion.remove(t1);
               // borrar = t1;
                //poblacion.remove(sel);
            }

            poblacion.clear();
            poblacion.addAll(poblacion_futura);
            poblacion_futura.clear();

            //Como tenemos elitismo, los n peores individuos "mueren"
            for(int h = 0; h< n_eli ; h++)
                poblacion.remove(poblacion.size()-1);

            i=0;
        for(individuo a : poblacion){
            System.err.print(".");
            if(i%n_sal_pantalla==0){
                long totalTiempo = System.currentTimeMillis() - tiempoInicio;
                System.err.print(i+"("+totalTiempo/1000/60+" min)");
            }
           

                fitness(a);
                i++;
        }
            System.err.print("\n");
            Collections.sort(poblacion, new IndividuoComparator());

            //Almacenamos
        try{
        salida = new FileWriter("./logs/genera"+Integer.toString(generaciones)+".txt");
        pw = new PrintWriter (salida);

        for(individuo a: poblacion){
          //System.err.println(a.ToString());
            pw.println(a.ToString());

        }
        }catch (Exception e) {
             e.printStackTrace();
        } finally {
           try {
           // Nuevamente aprovechamos el finally para
           // asegurarnos que se cierra el fichero.
           if (null != salida)
              salida.close();
           } catch (Exception e2) {
              e2.printStackTrace();
           }
        }

        }
       
    }
}
